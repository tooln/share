#!/bin/bash

gnome-terminal --tab -- bash -c "cd terminal1 && ./scan.sh; exec bash"
gnome-terminal --tab -- bash -c "cd terminal2 && ./scan.sh; exec bash"
gnome-terminal --tab -- bash -c "cd terminal3 && ./scan.sh; exec bash"
gnome-terminal --tab -- bash -c "cd terminal4 && ./scan.sh; exec bash"
gnome-terminal --tab -- bash -c "cd terminal5 && ./scan.sh; exec bash"
gnome-terminal --tab -- bash -c "cd terminal6 && ./scan.sh; exec bash"
gnome-terminal --tab -- bash -c "cd terminal7 && ./scan.sh; exec bash"
gnome-terminal --tab -- bash -c "cd terminal8 && ./scan.sh; exec bash"
gnome-terminal --tab -- bash -c "cd terminal9 && ./scan.sh; exec bash"