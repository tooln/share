#!/bin/bash

# Run terminal1 in the current pane
cd terminal4 &

# Split horizontally and run terminal2 in the new pane
tmux split-window -h "cd terminal5 && ./scan.sh; exec bash"
tmux split-window -h "cd terminal6 && ./scan.sh; exec bash"

# Balance the panes for better view (optional)
tmux select-layout even-horizontal